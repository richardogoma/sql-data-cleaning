# Changelog

## v1.0.0

### Added or Changed
* Uploaded the T-SQL Script
* Modified the README file
* Uploaded the Dirty and Clean Datasets
* Added this changelog :)

## v1.0.1
* Add the dataviz for the cleaning ops
* Addded the median script developed for the wrangling of the dataset

